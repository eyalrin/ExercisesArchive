package com.here.error;

public class IllegalCharException extends Exception {
    public IllegalCharException() {
        super();
    }
}
