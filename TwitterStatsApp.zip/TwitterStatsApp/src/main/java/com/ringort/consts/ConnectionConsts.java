package com.ringort.consts;

public class ConnectionConsts {
    // Note: Should be read from a Key-Value store like Consul or Zookeeper (or config file) - Used class for simplicity
    public static String oAuthConsumerKey = "89fN8H0aiWE14LjUd6xkK2x4u";
    public static String oAuthConsumerSecret = "dUXhUDmJd38JmbM1jlLLzUO6lsk0p18FBjVzYmuD1nFS7c7j43";
    public static String oAuthAccessToken = "392092334-eLzUQgBCRdhfGEcXwWUmUdTg9XwRiD09OSw3I57g";
    public static String oAuthAccessTokenSecret = "j3xXhnGiTBlYSgpI0igD14DTFEP8VGbMr4XyQnDhfI55p";
}
